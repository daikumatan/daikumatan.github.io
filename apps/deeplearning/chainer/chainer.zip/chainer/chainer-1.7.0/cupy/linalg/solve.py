# flake8: NOQA
# "flake8: NOQA" to suppress warning "H104  File contains nothing but comments"

# TODO(okuta): Implement solve


# TODO(okuta): Implement tensorsolve


# TODO(okuta): Implement lstsq


# TODO(okuta): Implement inv


# TODO(okuta): Implement pinv


# TODO(okuta): Implement tensorinv
