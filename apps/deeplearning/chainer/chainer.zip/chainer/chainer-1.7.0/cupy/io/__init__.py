# Functions from the following NumPy document
# http://docs.scipy.org/doc/numpy/reference/routines.io.html

# "NOQA" to suppress flake8 warning
from cupy.io import formatting  # NOQA
from cupy.io import npz  # NOQA
from cupy.io import rawfile  # NOQA
from cupy.io import text  # NOQA
