from chainer.function_hooks import timer


TimerHook = timer.TimerHook
