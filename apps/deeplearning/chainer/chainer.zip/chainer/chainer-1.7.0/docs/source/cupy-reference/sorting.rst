Sorting, Searching, and Counting
================================

.. autofunction:: cupy.argmax
.. autofunction:: cupy.argmin
.. autofunction:: cupy.count_nonzero
.. autofunction:: cupy.where
