Optimizers
==========

.. currentmodule:: chainer.optimizers

.. autoclass:: AdaDelta
.. autoclass:: AdaGrad
.. autoclass:: Adam
.. autoclass:: MomentumSGD
.. autoclass:: NesterovAG
.. autoclass:: RMSprop
.. autoclass:: RMSpropGraves
.. autoclass:: SGD
