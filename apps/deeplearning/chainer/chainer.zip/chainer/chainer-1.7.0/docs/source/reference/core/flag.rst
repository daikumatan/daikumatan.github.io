Flag
----

.. currentmodule:: chainer

.. autoclass:: Flag
   :members:
.. autodata:: ON
.. autodata:: OFF
.. autodata:: AUTO
.. autofunction:: chainer.flag.aggregate_flags
