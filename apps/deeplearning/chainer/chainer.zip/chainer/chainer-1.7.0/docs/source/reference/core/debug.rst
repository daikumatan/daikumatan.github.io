Debug mode
==========

In debug mode, Chainer checks values of variables on runtime and shows more
detailed error messages.
It helps you to debug your programs.
Instead it requires additional overhead time.


.. currentmodule:: chainer

.. autofunction:: is_debug
.. autofunction:: set_debug
